  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
       <!-- Main content -->
    <section class="content">
      <!-- Main row -->
      <div class="box">
        <div class="box-body text-center">
        <img width="30%" src="<?php echo base_url();?>assets/HomePage/images/muh.jpg">
        </div>
        <div class="row text-center">
          <h1>SELAMAT DATANG</h1>
        </div>
        <!-- right col -->
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  